#! /bin/bash



trap "hello " INT



trap -p  SIGINT


#exit 0