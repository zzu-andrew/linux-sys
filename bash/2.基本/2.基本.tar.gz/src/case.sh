#! /bin/bash

case $1 in
1) echo "\$1 = 1" ;;
2) echo "\$1 = 2" ;;
esac